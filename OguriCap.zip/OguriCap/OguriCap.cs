﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using LOR_DiceSystem;
using Sound;
using UI;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

namespace OguriCap
{
    public class BufAdder
    {
        public static void AddShin(BattleUnitModel target, int amount)
        {
            bool isBoss = target.passiveDetail.HasPassive<PassiveAbility_CindGray_BossManager>();

            if (isBoss)
            {
                var shinBuf = target.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_CindGray_BossOguriShin) as BattleUnitBuf_CindGray_BossOguriShin;
                if (shinBuf == null)
                {
                    shinBuf = new BattleUnitBuf_CindGray_BossOguriShin { stack = 0 };
                    target.bufListDetail.AddBuf(shinBuf);
                }
                shinBuf.stack += amount;

                var mangBuf = target.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_CindGray_BossOguriMang) as BattleUnitBuf_CindGray_BossOguriMang;
                int currentMang = mangBuf != null ? mangBuf.stack : 0;

                while (shinBuf.stack >= 5 && currentMang < 2)
                {
                    shinBuf.stack -= 5;
                    AddMang(target, 1);
                    currentMang++;
                }

                if (currentMang >= 2 && shinBuf.stack > 5) shinBuf.stack = 5;
            }
            else
            {
                var shinBuf = target.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_CindGray_PlayerOguriShin) as BattleUnitBuf_CindGray_PlayerOguriShin;
                if (shinBuf == null)
                {
                    shinBuf = new BattleUnitBuf_CindGray_PlayerOguriShin { stack = 0 };
                    target.bufListDetail.AddBuf(shinBuf);
                }
                shinBuf.stack += amount;

                var mangBuf = target.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_CindGray_PlayerOguriMang) as BattleUnitBuf_CindGray_PlayerOguriMang;
                int currentMang = mangBuf != null ? mangBuf.stack : 0;

                while (shinBuf.stack >= 5 && currentMang < 2)
                {
                    shinBuf.stack -= 5;
                    AddMang(target, 1);
                    currentMang++;
                }

                if (currentMang >= 2 && shinBuf.stack > 5) shinBuf.stack = 5;
            }
        }

        public static void AddMang(BattleUnitModel target, int amount)
        {
            bool isBoss = target.passiveDetail.HasPassive<PassiveAbility_CindGray_BossManager>();

            if (isBoss)
            {
                var mangBuf = target.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_CindGray_BossOguriMang) as BattleUnitBuf_CindGray_BossOguriMang;
                if (mangBuf == null)
                {
                    mangBuf = new BattleUnitBuf_CindGray_BossOguriMang { stack = 0 };
                    target.bufListDetail.AddBuf(mangBuf);
                }
                mangBuf.stack += amount;
                if (mangBuf.stack > 2) mangBuf.stack = 2;
            }
            else
            {
                var mangBuf = target.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_CindGray_PlayerOguriMang) as BattleUnitBuf_CindGray_PlayerOguriMang;
                if (mangBuf == null)
                {
                    mangBuf = new BattleUnitBuf_CindGray_PlayerOguriMang { stack = 0 };
                    target.bufListDetail.AddBuf(mangBuf);
                }
                mangBuf.stack += amount;
                if (mangBuf.stack > 2) mangBuf.stack = 2;
            }
        }

        public static void AddPoise(BattleUnitModel target, int amount)
        {
            var poiseBuf = target.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_Poise) as BattleUnitBuf_Poise;
            if (poiseBuf == null)
            {
                poiseBuf = new BattleUnitBuf_Poise { stack = 0 };
                target.bufListDetail.AddBuf(poiseBuf);
            }
            poiseBuf.stack += amount;
        }

        public static void AddRupture(BattleUnitModel target, int amount)
        {
            var ruptureBuf = target.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_Rupture) as BattleUnitBuf_Rupture;
            if (ruptureBuf == null)
            {
                ruptureBuf = new BattleUnitBuf_Rupture { stack = 0 };
                target.bufListDetail.AddBuf(ruptureBuf);
            }
            ruptureBuf.stack += amount;
        }
    }

    public class PassiveAbility_CindGray_ManagerBase : PassiveAbilityBase
    {
        public bool isAshen = false;
        public float hpAtStartOfCombat = 0;
        public int consecutiveNoDamageScenes = 0;
        public bool bypassShield = false;

        public bool gateTriggeredThisScene = false;

        public override void OnWaveStart()
        {
            isAshen = false;
            consecutiveNoDamageScenes = 0;
            hpAtStartOfCombat = owner.hp;
            owner.bufListDetail.AddBuf(new BattleUnitBuf_CindGray_Cinderella());
        }

        public override void OnStartBattle()
        {
            hpAtStartOfCombat = owner.hp;
        }

        public override void OnRoundStart()
        {
            gateTriggeredThisScene = false;

            if (isAshen && owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_CindGray_AshenMonster) == null)
                owner.bufListDetail.AddBuf(new BattleUnitBuf_CindGray_AshenMonster());
            else if (!isAshen && owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_CindGray_Cinderella) == null)
                owner.bufListDetail.AddBuf(new BattleUnitBuf_CindGray_Cinderella());
        }

        public override float DmgFactor(int dmg, DamageType type = DamageType.ETC, KeywordBuf keyword = KeywordBuf.None)
        {
            if (bypassShield || dmg <= 0) return base.DmgFactor(dmg, type, keyword);

            var shield = owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_CindGray_Shield) as BattleUnitBuf_CindGray_Shield;

            if (shield != null && shield.stack > 0)
            {
                if (shield.stack >= dmg)
                {
                    shield.stack -= dmg;
                    if (shield.stack <= 0) shield.Destroy();
                    return 0f;
                }
                else
                {
                    int remainingDmg = dmg - shield.stack;
                    shield.stack = 0;
                    shield.Destroy();
                    return (float)remainingDmg / (float)dmg;
                }
            }
            return base.DmgFactor(dmg, type, keyword);
        }

        public void EnterAshenForm()
        {
            isAshen = true;
            owner.bufListDetail.RemoveBufAll(typeof(BattleUnitBuf_CindGray_Cinderella));
            owner.bufListDetail.AddBuf(new BattleUnitBuf_CindGray_AshenMonster());
            SingletonBehavior<BattleManagerUI>.Instance.StartCoroutine(TransformToAshenMonster());
        }

        public void HealToHalfMaxHp()
        {
            int halfHp = owner.MaxHp / 2;
            if (owner.hp < halfHp) owner.RecoverHP(halfHp - (int)owner.hp);
        }

        public void LethalGateRecovery()
        {
            owner.RecoverBreakLife(1);
            owner.breakDetail.RecoverBreak(owner.breakDetail.GetDefaultBreakGauge());
            owner.breakDetail.nextTurnBreak = false;
            owner.bufListDetail.RemoveBufAll(KeywordBuf.Stun);

            owner.turnState = BattleUnitTurnState.WAIT_CARD;
            if (owner.speedDiceResult.Count == 0) owner.RollSpeedDice();
        }

        public bool PreventStaggerAtThreshold(float threshold)
        {
            if (owner.hp <= threshold + 1f)
            {
                LethalGateRecovery();
                return true;
            }
            return false;
        }

        public IEnumerator TransformToAshenMonster()
        {
            SingletonBehavior<SoundEffectManager>.Instance.PlayClip("Buf/Effect_Index_Unlock");

            UnityEngine.Object burstObj = Resources.Load("Prefabs/Battle/SpecialEffect/IndexRelease_ActivateParticle");
            if (burstObj != null)
            {
                GameObject burst = UnityEngine.Object.Instantiate(burstObj) as GameObject;
                burst.transform.parent = owner.view.charAppearance.transform;
                burst.transform.localPosition = Vector3.zero;
                burst.transform.localRotation = Quaternion.identity;
                burst.transform.localScale = Vector3.one;
            }

            IndexReleaseAura existingAura = owner.view.charAppearance.GetComponentInChildren<IndexReleaseAura>();
            if (existingAura == null)
            {
                UnityEngine.Object auraObj = Resources.Load("Prefabs/Battle/SpecialEffect/IndexRelease_Aura");
                if (auraObj != null)
                {
                    GameObject aura = UnityEngine.Object.Instantiate(auraObj) as GameObject;
                    aura.transform.parent = owner.view.charAppearance.transform;
                    aura.transform.localPosition = Vector3.zero;
                    aura.transform.localRotation = Quaternion.identity;
                    aura.transform.localScale = Vector3.one;

                    IndexReleaseAura component = aura.GetComponent<IndexReleaseAura>();
                    if (component != null) component.Init(owner.view);
                }
            }
            yield return YieldCache.WaitForSeconds(0.2f);
        }
    }

    public class PassiveAbility_CindGray_PlayerManager : PassiveAbility_CindGray_ManagerBase
    {
        public static string Desc = "At the start of each Wave, heal to 50% Max HP if below. Upon taking lethal damage, survive, heal to 50% Max HP, gain damage immunity for the Scene, recover from Stagger next Scene, and change to The Ashen Monster.";
        private string modId = "OguriCap";

        public override int GetMinHp() => !isAshen ? 1 : base.GetMinHp();
        public float cumulativeHealing = 0f;
        public float cumulativeDamage = 0f;

        public override void OnWaveStart()
        {
            base.OnWaveStart(); // Resets Ashen state
            cumulativeHealing = 0f;
            cumulativeDamage = 0f;
            HealToHalfMaxHp();
        }

        public override void OnRecoverHp(int amount)
        {
            if (amount <= 0) return;
            cumulativeHealing += amount;
            while (cumulativeHealing >= 25f)
            {
                cumulativeHealing -= 25f;
                BufAdder.AddShin(owner, 1);
            }
        }

        public override void OnTakeDamageByAttack(BattleDiceBehavior atkDice, int dmg)
        {
            base.OnTakeDamageByAttack(atkDice, dmg);
            if (dmg > 0)
            {
                cumulativeDamage += dmg;
                while (cumulativeDamage >= 25f)
                {
                    cumulativeDamage -= 25f;
                    BufAdder.AddShin(owner, 1);
                }
            }
        }

        public override void OnRoundStart()
        {
            base.OnRoundStart();

            if (owner.emotionDetail.EmotionLevel >= 2)
            {
                if (!owner.personalEgoDetail.GetCardAll().Exists(x => x.GetID() == new LorId(modId, 37770011)))
                    owner.personalEgoDetail.AddCard(new LorId(modId, 37770011));

                if (isAshen && !owner.personalEgoDetail.GetCardAll().Exists(x => x.GetID() == new LorId(modId, 37770012)))
                    owner.personalEgoDetail.AddCard(new LorId(modId, 37770012));
            }
        }

        public override void OnRoundEndTheLast()
        {
            base.OnRoundEndTheLast();

            if (!isAshen && owner.hp <= 1f)
            {
                EnterAshenForm();
                HealToHalfMaxHp();
                LethalGateRecovery(); 
            }
        }

        public override bool OnBreakGageZero()
        {
            if (!isAshen) return PreventStaggerAtThreshold(1f);
            return false;
        }
    }

    public class PassiveAbility_CindGray_BossManager : PassiveAbility_CindGray_ManagerBase
    {
        public static string Desc = "At the start of each Act, heal 25% of your Max HP and gain The Gray Cinderella/Ashen Monster passive based on the current phase. Generate 1 Shin (心) - The Gray Cinderella upon hitting a target 5 times, killing a target, or losing 25% of Max HP. Permanently gain 1 Mang (望) - The Gray Cinderella and change to the Ashen Monster upon reaching 40% of Max HP. HP does not fall below 40% before this occurs. Additionally, permanently gain 1 more Mang (望) - The Gray Cinderella and heal up to 50% of Max HP the first time this unit takes lethal damage. This unit's Undying Flame passive lasts for 2 Scenes instead of 1.";

        private int hitCount = 0;
        private int hpLostTracker = 0;
        public bool isSecondGateTriggered = false;
        private int _patternCount = 0;
        private string modId = "OguriCap";

        public override int SpeedDiceNumAdder() => 3;

        public override void OnWaveStart()
        {
            base.OnWaveStart(); 
            hitCount = 0;
            hpLostTracker = 0;
            _patternCount = 0;

            owner.RecoverHP(owner.MaxHp / 4);

            owner.bufListDetail.RemoveBufAll(typeof(BattleUnitBuf_CindGray_Cinderella));
            owner.bufListDetail.RemoveBufAll(typeof(BattleUnitBuf_CindGray_AshenMonster));

            if (isAshen)
            {
                owner.bufListDetail.AddBuf(new BattleUnitBuf_CindGray_AshenMonster());
                BufAdder.AddMang(owner, 1);
                SingletonBehavior<BattleManagerUI>.Instance.StartCoroutine(TransformToAshenMonster());
            }
            else
            {
                owner.bufListDetail.AddBuf(new BattleUnitBuf_CindGray_Cinderella());
            }

            UpdateThresholdBufs();
        }

        private void UpdateThresholdBufs()
        {
            float hpP = (float)owner.hp / owner.MaxHp;
            owner.bufListDetail.RemoveBufAll(typeof(BattleUnitBuf_CindGray_CravingMonster));
            owner.bufListDetail.RemoveBufAll(typeof(BattleUnitBuf_CindGray_HungryMonster));
            owner.bufListDetail.RemoveBufAll(typeof(BattleUnitBuf_CindGray_StarvingMonster));

            if (hpP <= 0.50f) owner.bufListDetail.AddBuf(new BattleUnitBuf_CindGray_StarvingMonster());
            else if (hpP <= 0.75f) owner.bufListDetail.AddBuf(new BattleUnitBuf_CindGray_HungryMonster());
            else if (hpP <= 0.90f) owner.bufListDetail.AddBuf(new BattleUnitBuf_CindGray_CravingMonster());
        }

        public override int GetMinHp()
        {
            if (!isAshen) return (int)(owner.MaxHp * 0.40f);
            if (!isSecondGateTriggered) return 1; 
            return base.GetMinHp();
        }

        public override void OnStartBattle()
        {
            base.OnStartBattle();
            ForceFillEmptySlots();
        }

        private void ForceFillEmptySlots()
        {
            if (owner.breakDetail.breakGauge <= 0 || owner.IsDead()) return;

            var myCards = owner.cardSlotDetail.cardAry;
            if (myCards == null) return;

            List<int> pool = new List<int> { 37770001, 37770002, 37770003, 37770004, 37770005 };
            var aliveEnemies = BattleObjectManager.instance.GetAliveList_opponent(owner.faction);

            if (aliveEnemies.Count == 0) return;

            for (int i = 0; i < owner.speedDiceResult.Count; i++)
            {
                if (i < myCards.Count && myCards[i] == null)
                {
                    BattleDiceCardModel fallbackCard = owner.allyCardDetail.AddTempCard(new LorId(modId, RandomUtil.SelectOne(pool)));
                    if (fallbackCard != null)
                    {
                        fallbackCard.SetCostToZero();
                        BattleUnitModel randomTarget = RandomUtil.SelectOne(aliveEnemies);

                        BattlePlayingCardDataInUnitModel forcedPlay = new BattlePlayingCardDataInUnitModel
                        {
                            owner = owner,
                            card = fallbackCard,
                            target = randomTarget,
                            targetSlotOrder = UnityEngine.Random.Range(0, randomTarget.speedDiceResult.Count),
                            slotOrder = i,
                            earlyTarget = randomTarget,
                            earlyTargetOrder = 0
                        };

                        myCards[i] = forcedPlay;
                    }
                }
            }
        }

        public override void OnSucceedAttack(BattleDiceBehavior behavior)
        {
            base.OnSucceedAttack(behavior);
            hitCount++;
            if (hitCount >= 5)
            {
                hitCount -= 5;
                BufAdder.AddShin(owner, 1);
            }
        }

        public override void OnKill(BattleUnitModel target)
        {
            base.OnKill(target);
            BufAdder.AddShin(owner, 1);
        }

        public override void OnTakeDamageByAttack(BattleDiceBehavior atkDice, int dmg)
        {
            base.OnTakeDamageByAttack(atkDice, dmg);
            hpLostTracker += dmg;
            int threshold = (int)(owner.MaxHp * 0.25f);
            while (hpLostTracker >= threshold)
            {
                hpLostTracker -= threshold;
                BufAdder.AddShin(owner, 1);
            }
        }

        public override void OnRoundStart()
        {
            base.OnRoundStart();
            SetBossDeck(); 
        }

        public override void OnRoundEndTheLast()
        {
            base.OnRoundEndTheLast();

            if (!isAshen && owner.hp <= (owner.MaxHp * 0.40f) + 1f)
            {
                EnterAshenForm();
                _patternCount = 0;
                BufAdder.AddMang(owner, 1);

                LethalGateRecovery(); 
            }

            if (isAshen && !isSecondGateTriggered && owner.hp <= 1f)
            {
                isSecondGateTriggered = true;
                _patternCount = 0;
                BufAdder.AddMang(owner, 1);

                HealToHalfMaxHp();
                LethalGateRecovery(); 
            }
        }

        public override void OnRoundEnd()
        {
            base.OnRoundEnd();

            if (owner.IsBreakLifeZero() || owner.bufListDetail.GetActivatedBuf(KeywordBuf.Stun) != null)
            {
                _patternCount = 0;
            }
            else
            {
                _patternCount++;
            }

            if (owner.emotionDetail.EmotionLevel < 5)
            {
                for (int i = 0; i < 3; i++) owner.emotionDetail.CreateEmotionCoin(EmotionCoinType.Positive);
            }
        }

        public override bool OnBreakGageZero()
        {
            if (!isAshen) return PreventStaggerAtThreshold(owner.MaxHp * 0.40f);
            if (!isSecondGateTriggered) return PreventStaggerAtThreshold(1f);
            return false;
        }

        public void SetBossDeck()
        {
            if (owner.breakDetail.breakGauge <= 0 || owner.IsDead()) return;

            owner.allyCardDetail.ExhaustAllCards();
            var flame = owner.passiveDetail.PassiveList.Find(x => x is PassiveAbility_CindGray_UndyingFlame) as PassiveAbility_CindGray_UndyingFlame;

            if (flame != null && flame.IsTriggered) { SetPhase4(); return; }
            if (isSecondGateTriggered) SetPhase3();
            else if (isAshen) SetPhase2();
            else SetPhase1();
        }

        private void SetPhase1()
        {
            if (_patternCount % 2 == 0) AddBossCard(37770007, 100);
            else AddBossCard(37770008, 100);
            AddBossCard(37770001, 90);
            AddBossCard(37770004, 80);
            AddBossCard(37770005, 70);
            FillRandom(10);
        }

        private void SetPhase2()
        {
            int step = _patternCount % 4;
            if (step == 0) { AddBossCard(37770009, 100); AddBossCard(37770005, 90); AddBossCard(37770003, 80); }
            else if (step == 1) { AddBossCard(37770007, 100); AddBossCard(37770001, 90, 2); AddBossCard(37770005, 80); AddBossCard(37770003, 70); FillRandom(10); }
            else if (step == 2) { AddBossCard(37770007, 100); AddBossCard(37770008, 90); AddBossCard(37770001, 80, 2); FillRandom(10); }
            else { AddBossCard(37770008, 100); AddBossCard(37770002, 90, 2); AddBossCard(37770004, 80, 2); FillRandom(10); }
        }

        private void SetPhase3()
        {
            int step = _patternCount % 4;
            if (step == 0) { AddBossCard(37770010, 100); AddBossCard(37770005, 90); AddBossCard(37770003, 80); }
            else if (step == 1) { AddBossCard(37770007, 100); AddBossCard(37770008, 95); AddBossCard(37770004, 90); AddBossCard(37770005, 85); AddBossCard(37770003, 80); FillRandom(10); }
            else if (step == 2) { AddBossCard(37770009, 100); AddBossCard(37770007, 95); AddBossCard(37770006, 90); AddBossCard(37770001, 85, 2); FillRandom(10); }
            else { AddBossCard(37770007, 100); AddBossCard(37770008, 95); AddBossCard(37770004, 90); AddBossCard(37770005, 85); AddBossCard(37770003, 80); FillRandom(10); }
        }

        private void SetPhase4()
        {
            AddBossCard(37770010, 100);
            AddBossCard(37770009, 100);
            AddBossCard(37770007, 90);
            AddBossCard(37770007, 90);
            AddBossCard(37770007, 90);
            AddBossCard(37770007, 90);
            AddBossCard(37770007, 90);
            FillRandom(10);
        }

        private void AddBossCard(int id, int priority, int count = 1)
        {
            for (int i = 0; i < count; i++)
            {
                BattleDiceCardModel card = owner.allyCardDetail.AddTempCard(new LorId(modId, id));
                if (card != null) { card.SetCostToZero(); card.SetPriorityAdder(priority); }
            }
        }

        private void FillRandom(int priority)
        {
            List<int> pool = new List<int> { 37770001, 37770002, 37770003, 37770004, 37770005 };
            int slots = owner.speedDiceCount;
            int current = 0;
            if (owner.allyCardDetail != null)
            {
                var hand = owner.allyCardDetail.GetHand();
                if (hand != null) current = hand.Count;
            }
            int cardsToAdd = (slots - current) + 2;
            if (cardsToAdd <= 0) cardsToAdd = 1;
            for (int i = 0; i < cardsToAdd; i++)
            {
                AddBossCard(RandomUtil.SelectOne(pool), priority);
            }
        }
    }

    public class PassiveAbility_CindGray_UndyingFlame : PassiveAbilityBase
    {
        private int _phase = 0;
        private int _surgeTurns = 0;
        public bool IsTriggered => _phase > 0;

        private bool IsAnotherPassiveProtecting()
        {
            foreach (PassiveAbilityBase passive in owner.passiveDetail.PassiveList)
            {
                if (passive == this) continue;
                if (passive.GetMinHp() > 0)
                {
                    return true;
                }
            }
            return false;
        }

        public override int GetMinHp()
        {
            if (_phase < 2 && !IsAnotherPassiveProtecting()) return 1;

            return base.GetMinHp();
        }

        public override int GetDamageReductionAll()
        {
            if (_phase == 0 && owner.hp <= 1f && !IsAnotherPassiveProtecting()) return 9999;
            if (_phase == 1) return 9999;
            return 0;
        }

        public override int GetBreakDamageReduction(BattleDiceBehavior behavior)
        {
            if (_phase == 0 && owner.hp <= 1f && !IsAnotherPassiveProtecting()) return 9999;
            if (_phase == 1) return 9999;
            return 0;
        }

        public override void OnRoundStart()
        {
            var manager = owner.passiveDetail.PassiveList.Find(x => x is PassiveAbility_CindGray_ManagerBase) as PassiveAbility_CindGray_ManagerBase;
            if (manager != null && manager.gateTriggeredThisScene) return;

            if (_phase == 0 && owner.hp <= 1f && !IsAnotherPassiveProtecting())
            {
                _phase = 1;

                owner.RecoverBreakLife(1);
                owner.ResetBreakGauge();
                owner.breakDetail.RecoverBreak(owner.breakDetail.GetDefaultBreakGauge());
                owner.breakDetail.nextTurnBreak = false;
                owner.bufListDetail.RemoveBufAll(KeywordBuf.Stun);
                owner.turnState = BattleUnitTurnState.WAIT_CARD;

                owner.bufListDetail.AddBuf(new BattleUnitBuf_CindGray_UndyingFlame());
                owner.bufListDetail.AddKeywordBufByEtc(KeywordBuf.Quickness, 6, owner);
                BufAdder.AddPoise(owner, 99);
                owner.cardSlotDetail.RecoverPlayPoint(99);

                // Draw cards if player, else, shimmering 1000 nukes
                var bossManager = owner.passiveDetail.PassiveList.Find(x => x is PassiveAbility_CindGray_BossManager) as PassiveAbility_CindGray_BossManager;
                if (bossManager != null) bossManager.SetBossDeck();
                else owner.allyCardDetail.DrawCards(5);

                SingletonBehavior<BattleManagerUI>.Instance.StartCoroutine(Transform());
            }
            else if (_phase == 1)
            {
                _surgeTurns++;

                if (!owner.bufListDetail.HasBuf<BattleUnitBuf_CindGray_UndyingFlame>())
                {
                    owner.bufListDetail.AddBuf(new BattleUnitBuf_CindGray_UndyingFlame());
                }

                owner.bufListDetail.AddKeywordBufByEtc(KeywordBuf.Quickness, 6, owner);
                BufAdder.AddPoise(owner, 3); 
                owner.cardSlotDetail.RecoverPlayPoint(99);

                var bossManager = owner.passiveDetail.PassiveList.Find(x => x is PassiveAbility_CindGray_BossManager) as PassiveAbility_CindGray_BossManager;
                if (bossManager != null) bossManager.SetBossDeck();
                else owner.allyCardDetail.DrawCards(5);
            }
        }

        public override void BeforeRollDice(BattleDiceBehavior behavior)
        {
            if (_phase == 1) behavior.ApplyDiceStatBonus(new DiceStatBonus { min = 3, max = 3 });
        }

        public override void OnLoseParrying(BattleDiceBehavior behavior)
        {
            bool isAttack = behavior.Detail == BehaviourDetail.Slash || behavior.Detail == BehaviourDetail.Penetrate || behavior.Detail == BehaviourDetail.Hit;

            if (_phase == 1 && isAttack && behavior.TargetDice != null)
            {
                int maxHpDmg = Mathf.FloorToInt(behavior.TargetDice.owner.MaxHp * 0.02f);
                int finalDmg = Mathf.Max(5, maxHpDmg);

                behavior.TargetDice.owner.TakeDamage(finalDmg, DamageType.Passive, owner);
            }
        }

        public override int SpeedDiceNumAdder()
        {
            return _phase == 1 ? 1 : 0;
        }

        public IEnumerator Transform()
        {
            yield return YieldCache.WaitForSeconds(0.65f);
            owner.view.charAppearance.ChangeMotion(ActionDetail.Default);
            SingletonBehavior<DiceEffectManager>.Instance.CreateCreatureEffect("Philip/Philip_Aura_Start", 1f, owner.view, owner.view, 1f);
            SoundEffectPlayer.PlaySound("Battle/Xiao_Vert");
            yield return YieldCache.WaitForSeconds(0.8f);

            if (SingletonBehavior<BattleSceneRoot>.Instance.currentMapObject != null)
            {
                SingletonBehavior<BattleSceneRoot>.Instance.currentMapObject.SetRunningState(false);
            }
            yield break;
        }
    }

    public class BattleUnitBuf_CindGray_UndyingFlame : BattleUnitBuf
    {
        protected override string keywordId => "CindGray_UndyingFlame";
        protected override string keywordIconId => "CindGray_UndyingFlame"; 

        public override int MaxPlayPointAdder()
        {
            return 3;
        }
    }

    public class PassiveAbility_CindGray_BossDiceAdd : PassiveAbilityBase
    {
        public override int SpeedDiceNumAdder()
        {
            return 3;
        }
    }

    public class PassiveAbility_CindGray_Indomitable : PassiveAbilityBase
    {
        public int maxCount = 99;
        public int currentCount = 0;

        public override void OnRoundStart()
        {
            currentCount = 0;
            DiceCardAbility_CindGray_Countermeasures.usedDice.Clear();
        }

        public override void OnStartTargetedOneSide(BattlePlayingCardDataInUnitModel attackerCard)
        {
            if (currentCount >= maxCount || owner.IsBreakLifeZero()) return;

            var keepCardList = owner.cardSlotDetail.keepCard?.GetDiceBehaviorList();

            if (keepCardList == null || keepCardList.Count == 0)
            {
                DiceCardXmlInfo cardItem = ItemXmlDataList.instance.GetCardItem(new LorId("OguriCap", 37770013));
                if (cardItem == null) return;

                List<BattleDiceBehavior> list = new List<BattleDiceBehavior>();

                foreach (var behaviorInfo in cardItem.DiceBehaviourList)
                {
                    BattleDiceBehavior b = new BattleDiceBehavior();
                    b.behaviourInCard = behaviorInfo.Copy();

                    b.behaviourInCard.Type = BehaviourType.Standby;
                    b.SetIndex(0);
                    b.AddAbility(new DiceCardAbility_CindGray_Countermeasures());

                    list.Add(b);
                }

                owner.cardSlotDetail.keepCard.AddBehaviours(cardItem, list);

                currentCount++;
            }
        }

        public override int GetDamageReductionAll() => 1;
        public override int GetBreakDamageReduction(BattleDiceBehavior behavior) => 1;
    }

    public class PassiveAbility_CindGray_BossIndomitable : PassiveAbility_CindGray_Indomitable
    {
        public static string Desc = "Take 1 less damage and stagger damage (Including non-attacks). Whenever receiving a one-sided attack, respond with [Countermeasures] skill. Every time this is used, inflict 1 Bind on self.";
        public override void OnWaveStart()
        {
            base.OnWaveStart();
            maxCount = 99;
        }
    }

    public class PassiveAbility_CindGray_PlayerIndomitable : PassiveAbility_CindGray_Indomitable
    {
        public static string Desc = "Take 1 less damage and stagger damage (Including non-attacks). Whenever receiving a one-sided attack, respond with [Countermeasures] skill, up to 2 times per Scene. Every time this is used, inflict 1 Bind on self.";
        public override void OnWaveStart()
        {
            base.OnWaveStart();
            maxCount = 2;
        }
    }

    public class BattleUnitBuf_CindGray_Cinderella : BattleUnitBuf
    {
        protected override string keywordId => "CindGray_Cinderella";
        protected override string keywordIconId => "CindGray_Cinderella";
        public override BufPositiveType positiveType => BufPositiveType.None;
        public override bool isAssimilation => true;

        public override void OnRoundStart()
        {
            var duplicates = _owner.bufListDetail.GetActivatedBufList().FindAll(x => x is BattleUnitBuf_CindGray_Cinderella);
            if (duplicates.Count > 1 && duplicates[0] != this) { Destroy(); return; }

            var manager = _owner.passiveDetail.PassiveList.Find(x => x is PassiveAbility_CindGray_ManagerBase) as PassiveAbility_CindGray_ManagerBase;
            if (manager == null) return;

            _owner.bufListDetail.RemoveBufAll(typeof(BattleUnitBuf_LetMyNameShakeHeavenAndEarth));

            if (_owner.hp >= manager.hpAtStartOfCombat)
            {
                manager.consecutiveNoDamageScenes++;
                float extraHeal = Mathf.Min(0.04f, 0.008f * (manager.consecutiveNoDamageScenes - 1));
                ApplyFormHeal(0.04f + extraHeal, manager);

                if ((float)_owner.hp / _owner.MaxHp > 0.75f)
                {
                    if (!_owner.bufListDetail.GetActivatedBufList().Exists(x => x is BattleUnitBuf_LetMyNameRockEarth))
                    {
                        _owner.bufListDetail.AddBuf(new BattleUnitBuf_LetMyNameRockEarth());
                    }
                }
            }
            else manager.consecutiveNoDamageScenes = 0;

            manager.hpAtStartOfCombat = _owner.hp;
        }

        public override void OnRoundEnd()
        {
            float missing = 1f - ((float)_owner.hp / _owner.MaxHp);
            int stacks = Mathf.FloorToInt(missing / 0.5f);

            if (stacks > 0)
            {
                _owner.bufListDetail.AddKeywordBufByEtc(KeywordBuf.Strength, stacks, _owner);
                BufAdder.AddPoise(_owner, stacks); 
            }
        }

        private void ApplyFormHeal(float percent, PassiveAbility_CindGray_ManagerBase mgr)
        {
            float mult = 1f;

            int mangStacks = 0;
            var bossMang = _owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_CindGray_BossOguriMang) as BattleUnitBuf_CindGray_BossOguriMang;
            if (bossMang != null) mangStacks = bossMang.stack;
            else
            {
                var playerMang = _owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_CindGray_PlayerOguriMang) as BattleUnitBuf_CindGray_PlayerOguriMang;
                if (playerMang != null) mangStacks = playerMang.stack;
            }

            if (mangStacks > 0) mult += (0.07f * mangStacks);

            var monster = _owner.passiveDetail.PassiveList.Find(x => x is PassiveAbility_CindGray_Monster) as PassiveAbility_CindGray_Monster;
            if (monster != null) mult *= monster.GetHealingMultiplier();

            int finalHeal = Mathf.RoundToInt(_owner.MaxHp * percent * mult);
            _owner.RecoverHP(finalHeal);
        }
    }

    public class BattleUnitBuf_CindGray_AshenMonster : BattleUnitBuf
    {
        protected override string keywordId => "CindGray_AshenMonster";
        protected override string keywordIconId => "CindGray_AshenMonster";
        public override BufPositiveType positiveType => BufPositiveType.None;
        public override bool isAssimilation => true;

        public override void OnRoundStart()
        {
            var duplicates = _owner.bufListDetail.GetActivatedBufList().FindAll(x => x is BattleUnitBuf_CindGray_AshenMonster);
            if (duplicates.Count > 1 && duplicates[0] != this) { Destroy(); return; }

            var manager = _owner.passiveDetail.PassiveList.Find(x => x is PassiveAbility_CindGray_ManagerBase) as PassiveAbility_CindGray_ManagerBase;
            if (manager == null) return;

            _owner.bufListDetail.RemoveBufAll(typeof(BattleUnitBuf_LetMyNameRockEarth));

            if (_owner.hp >= manager.hpAtStartOfCombat)
            {
                manager.consecutiveNoDamageScenes++;
                float extraHeal = Mathf.Min(0.10f, 0.01f * (manager.consecutiveNoDamageScenes - 1));
                ApplyFormHeal(0.08f + extraHeal, manager);

                if ((float)_owner.hp / _owner.MaxHp > 0.60f)
                {
                    if (!_owner.bufListDetail.GetActivatedBufList().Exists(x => x is BattleUnitBuf_LetMyNameShakeHeavenAndEarth))
                    {
                        _owner.bufListDetail.AddBuf(new BattleUnitBuf_LetMyNameShakeHeavenAndEarth());
                    }
                }
            }
            else manager.consecutiveNoDamageScenes = 0;

            manager.hpAtStartOfCombat = _owner.hp;
        }

        public override void OnRoundEnd()
        {
            float missing = 1f - ((float)_owner.hp / _owner.MaxHp);
            int str = Mathf.FloorToInt(missing / 0.30f);
            int dmgPoise = Mathf.FloorToInt(missing / 0.15f); 

            if (str > 0) _owner.bufListDetail.AddKeywordBufByEtc(KeywordBuf.Strength, str, _owner);

            if (dmgPoise > 0)
            {
                _owner.bufListDetail.AddKeywordBufByEtc(KeywordBuf.DmgUp, dmgPoise, _owner);
                BufAdder.AddPoise(_owner, dmgPoise); 
            }
        }

        private void ApplyFormHeal(float percent, PassiveAbility_CindGray_ManagerBase mgr)
        {
            float mult = 1f;

            int mangStacks = 0;
            var bossMang = _owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_CindGray_BossOguriMang) as BattleUnitBuf_CindGray_BossOguriMang;
            if (bossMang != null) mangStacks = bossMang.stack;
            else
            {
                var playerMang = _owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_CindGray_PlayerOguriMang) as BattleUnitBuf_CindGray_PlayerOguriMang;
                if (playerMang != null) mangStacks = playerMang.stack;
            }

            if (mangStacks > 0) mult += (0.07f * mangStacks);

            var monster = _owner.passiveDetail.PassiveList.Find(x => x is PassiveAbility_CindGray_Monster) as PassiveAbility_CindGray_Monster;
            if (monster != null) mult *= monster.GetHealingMultiplier();

            int finalHeal = Mathf.RoundToInt(_owner.MaxHp * percent * mult);
            _owner.RecoverHP(finalHeal);
        }
    }

    public class PassiveAbility_CindGray_StarlightOfKasamatsu : PassiveAbilityBase
    {
        public static string Desc = "Gain 1 Haste each Scene. If this unit is in the upper half of the percentile of the faster units, gain 3 Haste instead. If this unit's Speed is faster than the target by 2 or more, the target's dice power is reduced by 1 for every 2 speed difference (Max -5).";

        public override void OnWaveStart()
        {
            owner.bufListDetail.AddKeywordBufByEtc(KeywordBuf.Quickness, 1, owner);
        }

        public override void OnRoundEnd()
        {
            int haste = CheckIfUpperHalfSpeed() ? 3 : 1;
            owner.bufListDetail.AddKeywordBufByEtc(KeywordBuf.Quickness, haste, owner);
        }

        public override void BeforeRollDice(BattleDiceBehavior behavior)
        {
            if (behavior.card != null && behavior.TargetDice != null && behavior.TargetDice.card != null)
            {
                int ownerSpeed = behavior.card.speedDiceResultValue;
                int targetSpeed = behavior.TargetDice.card.speedDiceResultValue;

                if (ownerSpeed - targetSpeed >= 2)
                {
                    int diff = ownerSpeed - targetSpeed;
                    int powerLoss = Mathf.Min(5, diff / 2);
                    behavior.TargetDice.ApplyDiceStatBonus(new DiceStatBonus { power = -powerLoss });
                }
            }
        }

        private bool CheckIfUpperHalfSpeed()
        {
            List<int> speeds = new List<int>();
            int myMax = 0;
            foreach (var unit in BattleObjectManager.instance.GetAliveList())
            {
                int max = 0;
                if (unit.speedDiceResult != null)
                {
                    foreach (var dice in unit.speedDiceResult)
                        if (dice.value > max) max = dice.value;
                }
                speeds.Add(max);
                if (unit == owner) myMax = max;
            }
            speeds.Sort();
            return speeds.Count > 0 && myMax >= speeds[speeds.Count / 2];
        }
    }

    public class PassiveAbility_CindGray_Monster : PassiveAbilityBase
    {
        public static string Desc = "At the end of the Scene, take 1% max HP damage. This increases by 1.5% per Scene (max of 12% total, additive). Gain Craving Monster / Hungry Monster / Starved Monster based on remaining HP on self, checked at the start of each Scene.";

        private int sceneCount = 0;
        private int currentTier = 0;

        public int rupturePoiseCount = 0;
        public int critRuptureCount = 0;

        public int graceCraving = 0;
        public int graceHungry = 0;
        public int graceStarving = 0;

        public override void OnRoundStart()
        {
            rupturePoiseCount = 0;
            critRuptureCount = 0;

            UpdateThresholdTrackers();
            UpdateMonsterTier();
        }

        public override void OnRecoverHp(int amount)
        {
            base.OnRecoverHp(amount);
            UpdateThresholdTrackers();
            UpdateMonsterTier();
        }

        public override void OnTakeDamageByAttack(BattleDiceBehavior atkDice, int dmg)
        {
            base.OnTakeDamageByAttack(atkDice, dmg);
            UpdateThresholdTrackers();
            UpdateMonsterTier();
        }

        public void UpdateThresholdTrackers()
        {
            float hpP = (float)owner.hp / owner.MaxHp;

            // Updated Thresholds: 40% / 60% / 80%
            if (hpP <= 0.40f) graceStarving = 2;
            if (hpP <= 0.60f) graceHungry = 2;
            if (hpP <= 0.80f) graceCraving = 2;
        }

        public override void OnRoundEnd()
        {
            sceneCount++;

            bool isBoss = owner.passiveDetail.HasPassive<PassiveAbility_CindGray_BossManager>();
            float baseDmg = isBoss ? 0.005f : 0.01f;
            float ramp = isBoss ? 0.0075f : 0.015f;
            float maxDmg = isBoss ? 0.06f : 0.12f;

            int selfDmg = (int)(owner.MaxHp * Mathf.Min(maxDmg, baseDmg + (ramp * (sceneCount - 1))));

            var manager = owner.passiveDetail.PassiveList.Find(x => x is PassiveAbility_CindGray_ManagerBase) as PassiveAbility_CindGray_ManagerBase;
            if (manager != null) manager.bypassShield = true;
            owner.TakeDamage(selfDmg, DamageType.Passive, owner);
            if (manager != null) manager.bypassShield = false;

            if (graceStarving > 0) graceStarving--;
            if (graceHungry > 0) graceHungry--;
            if (graceCraving > 0) graceCraving--;

            UpdateThresholdTrackers();
            UpdateMonsterTier();
        }

        public override void OnKill(BattleUnitModel target)
        {
            base.OnKill(target);
            owner.RecoverHP((int)(owner.MaxHp * 0.20f));
        }

        public int ProcessRuptureTrigger(int baseRuptureDmg)
        {
            UpdateThresholdTrackers();
            UpdateMonsterTier();

            int finalDmg = baseRuptureDmg;

            float hpP = (float)owner.hp / owner.MaxHp;

            bool isGracePeriod = false;
            float tierHealMult = 0f;

            if (graceStarving > 0)
            {
                if (hpP <= 0.40f) tierHealMult = 2.0f;
                else isGracePeriod = true;
            }
            else if (graceHungry > 0)
            {
                if (hpP <= 0.60f) tierHealMult = 1.5f;
                else isGracePeriod = true;
            }
            else if (graceCraving > 0)
            {
                if (hpP <= 0.80f) tierHealMult = 1.0f;
                else isGracePeriod = true;
            }

            if (isGracePeriod)
            {
                finalDmg = baseRuptureDmg * 2;

                var manager = owner.passiveDetail.PassiveList.Find(x => x is PassiveAbility_CindGray_ManagerBase) as PassiveAbility_CindGray_ManagerBase;
                if (manager != null) manager.bypassShield = true;
                owner.TakeDamage(baseRuptureDmg, DamageType.Passive, owner);
                if (manager != null) manager.bypassShield = false;
            }

            if (rupturePoiseCount < 3 && finalDmg >= 3)
            {
                rupturePoiseCount++;
                BufAdder.AddPoise(owner, 1);
            }

            if (tierHealMult > 0f)
            {
                int baseHeal = Mathf.CeilToInt(finalDmg * tierHealMult);
                int bossMult = owner.passiveDetail.HasPassive<PassiveAbility_CindGray_BossManager>() ? 3 : 1;
                owner.RecoverHP(baseHeal * bossMult);
            }

            UpdateThresholdTrackers();
            UpdateMonsterTier();

            return finalDmg;
        }

        public void OnCriticalHit(BattleUnitModel target) // Inflict 3 Rupture after Critting (3 times per Scene)
        {
            if (critRuptureCount < 3)
            {
                critRuptureCount++;
                BufAdder.AddRupture(target, 3);
            }
        }

        public float GetHealingMultiplier()
        {
            float bonus = 1.0f;
            float hpP = (float)owner.hp / owner.MaxHp;

            bool isGracePeriod = false;

            if (graceStarving > 0 && hpP > 0.40f) isGracePeriod = true;
            else if (graceHungry > 0 && hpP > 0.60f) isGracePeriod = true;
            else if (graceCraving > 0 && hpP > 0.80f) isGracePeriod = true;

            if (isGracePeriod) bonus += 0.18f;
            else if (graceStarving > 0) bonus += 0.16f;
            else if (graceHungry > 0) bonus += 0.12f;
            else if (graceCraving > 0) bonus += 0.08f;

            if (owner.passiveDetail.HasPassive<PassiveAbility_CindGray_BossManager>())
            {
                bonus *= 0.5f;
            }

            return bonus;
        }

        private void UpdateMonsterTier()
        {
            int newTier = 0;

            if (graceStarving > 0) newTier = 3;
            else if (graceHungry > 0) newTier = 2;
            else if (graceCraving > 0) newTier = 1;

            currentTier = newTier;

            owner.bufListDetail.RemoveBufAll(typeof(BattleUnitBuf_CindGray_CravingMonster));
            owner.bufListDetail.RemoveBufAll(typeof(BattleUnitBuf_CindGray_HungryMonster));
            owner.bufListDetail.RemoveBufAll(typeof(BattleUnitBuf_CindGray_StarvingMonster));

            if (newTier == 3) owner.bufListDetail.AddBuf(new BattleUnitBuf_CindGray_StarvingMonster());
            else if (newTier == 2) owner.bufListDetail.AddBuf(new BattleUnitBuf_CindGray_HungryMonster());
            else if (newTier == 1) owner.bufListDetail.AddBuf(new BattleUnitBuf_CindGray_CravingMonster());
        }

        // Give DMG/STG Res based on Craving / Hungry / Starving
        public override int GetDamageReductionAll()
        {
            return currentTier;
        }
        public override int GetBreakDamageReduction(BattleDiceBehavior behavior)
        {
            return currentTier;
        }
    }

    public class BattleUnitBuf_LetMyNameRockEarth : BattleUnitBuf
    {
        protected override string keywordId => "LetMyNameRockEarth";
        protected override string keywordIconId => "LetMyNameRockEarth";
        private int count = 0;

        public override void OnRoundStart()
        {
            var duplicates = _owner.bufListDetail.GetActivatedBufList().FindAll(x => x is BattleUnitBuf_LetMyNameRockEarth);
            if (duplicates.Count > 1 && duplicates[0] != this) { Destroy(); return; }

            if ((float)_owner.hp / _owner.MaxHp <= 0.75f || _owner.bufListDetail.GetActivatedBufList().Exists(x => x is BattleUnitBuf_LetMyNameShakeHeavenAndEarth))
            {
                Destroy();
                return;
            }
        }

        public override void OnWinParrying(BattleDiceBehavior behavior)
        {
            if (count < 5 && behavior.card != null && behavior.TargetDice?.card != null && (behavior.card.speedDiceResultValue - behavior.TargetDice.card.speedDiceResultValue) >= 5)
            {
                behavior.TargetDice.owner.bufListDetail.AddKeywordBufByEtc(KeywordBuf.Weak, 1, _owner);
                count++;
            }
        }

        public override void OnRoundEnd()
        {
            if ((float)_owner.hp / _owner.MaxHp <= 0.75f) Destroy();
        }
    }

    public class BattleUnitBuf_LetMyNameShakeHeavenAndEarth : BattleUnitBuf
    {
        protected override string keywordId => "LetMyNameShakeHeavenAndEarth";
        protected override string keywordIconId => "LetMyNameShakeHeavenAndEarth";
        private int count = 0;
        private int feebleTotal = 0;

        public override void OnRoundStart()
        {
            var duplicates = _owner.bufListDetail.GetActivatedBufList().FindAll(x => x is BattleUnitBuf_LetMyNameShakeHeavenAndEarth);
            if (duplicates.Count > 1 && duplicates[0] != this) { Destroy(); return; }

            if ((float)_owner.hp / _owner.MaxHp <= 0.60f)
            {
                Destroy();
                return;
            }
        }

        public override void OnWinParrying(BattleDiceBehavior b)
        {
            if (count < 8 && b.card != null && b.TargetDice?.card != null && (b.card.speedDiceResultValue - b.TargetDice.card.speedDiceResultValue) >= 5)
            {
                int f = UnityEngine.Random.Range(1, 3);
                b.TargetDice.owner.bufListDetail.AddKeywordBufByEtc(KeywordBuf.Weak, f, _owner);
                b.TargetDice.owner.bufListDetail.AddKeywordBufByEtc(KeywordBuf.Vulnerable, 1, _owner);
                feebleTotal += f; count++;
            }
        }

        public override void OnRoundEnd()
        {
            int binds = 0;
            var opponents = BattleObjectManager.instance.GetAliveList_opponent(_owner.faction);
            foreach (var e in opponents) binds += e.bufListDetail.GetKewordBufStack(KeywordBuf.Binding);
            if (binds >= 15 && feebleTotal > 0) foreach (var e in opponents) e.bufListDetail.AddKeywordBufByEtc(KeywordBuf.Weak, feebleTotal / 2, _owner);

            if ((float)_owner.hp / _owner.MaxHp <= 0.60f) Destroy();
        }
    }

    public class BattleUnitBuf_CindGray_CravingMonster : BattleUnitBuf
    {
        protected override string keywordId => "OguriCraving";
        public override BufPositiveType positiveType => BufPositiveType.None;
        public override void OnUseCard(BattlePlayingCardDataInUnitModel c) => _owner.cardSlotDetail.RecoverPlayPointByCard(1);
    }

    public class BattleUnitBuf_CindGray_HungryMonster : BattleUnitBuf
    {
        protected override string keywordId => "OguriHungry";
        public override BufPositiveType positiveType => BufPositiveType.None;
        public override void OnUseCard(BattlePlayingCardDataInUnitModel c) => _owner.cardSlotDetail.RecoverPlayPointByCard(UnityEngine.Random.Range(1, 3));
    }

    public class BattleUnitBuf_CindGray_StarvingMonster : BattleUnitBuf
    {
        protected override string keywordId => "OguriStarving";
        public override BufPositiveType positiveType => BufPositiveType.None;

        public override void OnUseCard(BattlePlayingCardDataInUnitModel c)
        {
            _owner.cardSlotDetail.RecoverPlayPointByCard(UnityEngine.Random.Range(1, 4));
            if (UnityEngine.Random.Range(1, 101) <= 33) _owner.allyCardDetail.DrawCards(1);
        }

        public override void BeforeRollDice(BattleDiceBehavior b)
        {
            b.ApplyDiceStatBonus(new DiceStatBonus { min = 1, max = 1 });
        }
    }

    public class BattleUnitBuf_Rupture : BattleUnitBuf
    {
        protected override string keywordId => "Rupture";
        public override void OnTakeDamageByAttack(BattleDiceBehavior b, int dmg)
        {
            int ruptureDmg = stack;
            var monster = b.owner.passiveDetail.PassiveList.Find(x => x is PassiveAbility_CindGray_Monster) as PassiveAbility_CindGray_Monster;
            if (monster != null)
            {
                ruptureDmg = monster.ProcessRuptureTrigger(ruptureDmg);
            }

            _owner.TakeDamage(ruptureDmg, DamageType.Buf, b.owner);
            bool preserve = (b.owner.bufListDetail.GetKewordBufStack(KeywordBuf.Quickness) >= 5 && b.card?.card?.XmlData?.Script == "CindGray_FruitsOfLabor" && UnityEngine.Random.Range(0, 100) < 50);
            if (!preserve) stack -= stack / 3;
            if (stack <= 0) Destroy();
        }
    }

    public class BattleUnitBuf_Poise : BattleUnitBuf
    {
        protected override string keywordId => "Poise";
        public bool justCritted = false;

        public override void BeforeRollDice(BattleDiceBehavior b)
        {
            justCritted = false;

            bool isAttack = b.Detail == BehaviourDetail.Slash || b.Detail == BehaviourDetail.Penetrate || b.Detail == BehaviourDetail.Hit;
            bool isUndying = _owner.bufListDetail.HasBuf<BattleUnitBuf_CindGray_UndyingFlame>();

            if (isAttack && (isUndying || UnityEngine.Random.Range(1, 101) <= stack * 5))
            {
                justCritted = true;

                int originalMin = b.behaviourInCard.Min;
                int originalMax = b.behaviourInCard.Dice;

                int bonusMin = Mathf.CeilToInt(originalMin * 0.4f);
                int bonusMax = Mathf.CeilToInt(originalMax * 0.4f);

                // CDMG from 2 Mang
                int extraCritDmg = 0;
                var bossMang = _owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_CindGray_BossOguriMang) as BattleUnitBuf_CindGray_BossOguriMang;
                var playerMang = _owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_CindGray_PlayerOguriMang) as BattleUnitBuf_CindGray_PlayerOguriMang;

                if (bossMang != null && bossMang.stack >= 2)
                {
                    extraCritDmg = 25; 
                }
                else if (playerMang != null && playerMang.stack >= 2)
                {
                    extraCritDmg = 15; 
                }

                b.ApplyDiceStatBonus(new DiceStatBonus { min = bonusMin, max = bonusMax, dmgRate = extraCritDmg });

                b.AddAbility(new DiceCardAbility_CindGray_CritRupture());

                if (!isUndying) stack--;
            }
        }

        public override void OnSuccessAttack(BattleDiceBehavior b)
        {
            if (justCritted && b.card?.target != null)
            {
                var monster = _owner.passiveDetail.PassiveList.Find(x => x is PassiveAbility_CindGray_Monster) as PassiveAbility_CindGray_Monster;
                if (monster != null)
                {
                    monster.OnCriticalHit(b.card.target);
                }
            }
        }

        public override void OnRoundEnd() { if (--stack <= 0) Destroy(); }
    }

    public class DiceCardAbility_CindGray_CritRupture : DiceCardAbilityBase
    {
        public override void OnSucceedAttack(BattleUnitModel target)
        {
            if (target == null) return;

            var monster = owner.passiveDetail.PassiveList.Find(x => x is PassiveAbility_CindGray_Monster) as PassiveAbility_CindGray_Monster;
            if (monster != null)
            {
                monster.OnCriticalHit(target);
            }
        }
    }

    // BOSS VARIANT
    public class BattleUnitBuf_CindGray_BossOguriShin : BattleUnitBuf
    {
        protected override string keywordId => "CindGray_BossOguriShin";

        public override void OnRoundStart()
        {
            _owner.bufListDetail.AddKeywordBufByEtc(KeywordBuf.DmgUp, stack, _owner);

            int shieldAmount = (int)(_owner.MaxHp * 0.02f * stack);
            if (shieldAmount > 0)
            {
                var existingShield = _owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_CindGray_Shield) as BattleUnitBuf_CindGray_Shield;
                if (existingShield != null) existingShield.stack += shieldAmount;
                else
                {
                    existingShield = new BattleUnitBuf_CindGray_Shield { stack = 0 };
                    _owner.bufListDetail.AddBuf(existingShield);
                    existingShield.stack += shieldAmount;
                }
            }
        }
    }

    public class BattleUnitBuf_CindGray_BossOguriMang : BattleUnitBuf
    {
        protected override string keywordId => "CindGray_BossOguriMang";

        public override void BeforeRollDice(BattleDiceBehavior b)
        {
            if (stack >= 1)
            {
                int haste = _owner.bufListDetail.GetKewordBufStack(KeywordBuf.Quickness);
                int powerBonus = Mathf.Min(2, haste / 3);
                if (powerBonus > 0) b.ApplyDiceStatBonus(new DiceStatBonus { power = powerBonus });
            }

            if (stack >= 2)
            {
                if (b.card != null && b.TargetDice?.card != null)
                {
                    int speedDiff = b.card.speedDiceResultValue - b.TargetDice.card.speedDiceResultValue;
                    if (speedDiff > 0)
                    {
                        int maxBonus = Mathf.Min(2, speedDiff / 2);
                        int minBonus = maxBonus / 2;
                        if (maxBonus > 0) b.ApplyDiceStatBonus(new DiceStatBonus { min = minBonus, max = maxBonus });
                    }
                }

                // CDMG code is in Poise
            }
        }

        public override float DmgFactor(int dmg, DamageType type = DamageType.ETC, KeywordBuf keyword = KeywordBuf.None)
        {
            if (stack < 1) return 1f;
            float missingHpPercent = 100f - (((float)_owner.hp / _owner.MaxHp) * 100f);
            float reductionPercentage = (50f + missingHpPercent) / 3f;
            return (100f - reductionPercentage) / 100f;
        }

        public override float BreakDmgFactor(int dmg, DamageType type = DamageType.ETC, KeywordBuf keyword = KeywordBuf.None)
        {
            if (stack < 1) return 1f;
            float missingHpPercent = 100f - (((float)_owner.hp / _owner.MaxHp) * 100f);
            float reductionPercentage = (50f + missingHpPercent) / 3f;
            return (100f - reductionPercentage) / 100f;
        }
    }

    // PLAYER VARIANT
    public class BattleUnitBuf_CindGray_PlayerOguriShin : BattleUnitBuf
    {
        protected override string keywordId => "CindGray_PlayerOguriShin";

        public override void OnRoundStart()
        {
            _owner.bufListDetail.AddKeywordBufByEtc(KeywordBuf.DmgUp, stack, _owner);

            int shieldAmount = (int)(_owner.MaxHp * 0.07f * stack);
            if (shieldAmount > 0)
            {
                var existingShield = _owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_CindGray_Shield) as BattleUnitBuf_CindGray_Shield;
                if (existingShield != null) existingShield.stack += shieldAmount;
                else
                {
                    existingShield = new BattleUnitBuf_CindGray_Shield { stack = 0 };
                    _owner.bufListDetail.AddBuf(existingShield);
                    existingShield.stack += shieldAmount;
                }
            }
        }
    }

    public class BattleUnitBuf_CindGray_PlayerOguriMang : BattleUnitBuf
    {
        protected override string keywordId => "CindGray_PlayerOguriMang";

        public override void BeforeRollDice(BattleDiceBehavior b)
        {
            if (stack >= 1)
            {
                int haste = _owner.bufListDetail.GetKewordBufStack(KeywordBuf.Quickness);
                int powerBonus = Mathf.Min(2, haste / 3);
                if (powerBonus > 0) b.ApplyDiceStatBonus(new DiceStatBonus { power = powerBonus });
            }

            if (stack >= 2)
            {
                if (b.card != null && b.TargetDice?.card != null)
                {
                    int speedDiff = b.card.speedDiceResultValue - b.TargetDice.card.speedDiceResultValue;
                    if (speedDiff > 0)
                    {
                        int maxBonus = Mathf.Min(2, speedDiff / 2);
                        int minBonus = maxBonus / 2;

                        if (maxBonus > 0) b.ApplyDiceStatBonus(new DiceStatBonus { min = minBonus, max = maxBonus });
                    }
                }

                // CDMG code in Poise
            }
        }

        public override float DmgFactor(int dmg, DamageType type = DamageType.ETC, KeywordBuf keyword = KeywordBuf.None)
        {
            if (stack < 1) return 1f;
            float missingHpPercent = 100f - (((float)_owner.hp / _owner.MaxHp) * 100f);
            float reductionPercentage = (50f + missingHpPercent) / 5f;
            return (100f - reductionPercentage) / 100f;
        }

        public override float BreakDmgFactor(int dmg, DamageType type = DamageType.ETC, KeywordBuf keyword = KeywordBuf.None)
        {
            if (stack < 1) return 1f;
            float missingHpPercent = 100f - (((float)_owner.hp / _owner.MaxHp) * 100f);
            float reductionPercentage = (50f + missingHpPercent) / 5f;
            return (100f - reductionPercentage) / 100f;
        }
    }

    public class BattleUnitBuf_CindGray_Shield : BattleUnitBuf
    {
        protected override string keywordId => "CindGray_Shield";
        protected override string keywordIconId => "CindGray_Shield";

        public override void OnRoundStart()
        {
            int maxShield = (int)(_owner.MaxHp * 0.3f);
            if (stack > maxShield)
            {
                stack = maxShield;
            }
        }
    }

    public class DiceCardSelfAbility_CindGray_TimeToAwaken : DiceCardSelfAbilityBase
    {
        public static string Desc = "On Use Gain 2 Poise. At 6+ Poise, restore 2 Light";
        public override void OnUseCard()
        {
            BufAdder.AddPoise(owner, 2);
            var p = owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_Poise) as BattleUnitBuf_Poise;
            if (p != null && p.stack >= 6) owner.cardSlotDetail.RecoverPlayPointByCard(2);
        }
    }

    public class DiceCardAbility_CindGray_TimeToAwaken_1 : DiceCardAbilityBase
    {
        public static string Desc = "[On Clash Win] Gain 2 Poise";
        public override void OnWinParrying()
        {
            BufAdder.AddPoise(owner, 2);
        }
    }

    public class DiceCardAbility_CindGray_TimeToAwaken_2 : DiceCardAbilityBase
    {
        public static string Desc = "[On Crit] Deal bonus damage equal to Speed difference";
        public override void OnSucceedAttack()
        {
            var p = owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_Poise) as BattleUnitBuf_Poise;
            if (p != null && p.justCritted && behavior.TargetDice != null) card.target?.TakeDamage(Mathf.Abs(behavior.card.speedDiceResultValue - behavior.TargetDice.card.speedDiceResultValue), DamageType.Card_Ability, owner);
        }
    }

    public class DiceCardSelfAbility_CindGray_SteadyEffort : DiceCardSelfAbilityBase
    {
        public static string Desc = "Deal +15% more damage for every 2 Haste (max, 100%). [On Use] Draw 1 Page. If this unit has one of the fastest Speed Dice, draw 1 additional Page.";
        public override void OnUseCard()
        {
            owner.allyCardDetail.DrawCards(1);
            int max = 0;
            foreach (var u in BattleObjectManager.instance.GetAliveList()) foreach (var d in u.speedDiceResult) if (d.value > max) max = d.value;
            int myMax = 0;
            foreach (var d in owner.speedDiceResult) if (d.value > myMax) myMax = d.value;
            if (myMax >= max) owner.allyCardDetail.DrawCards(1);
        }
        public override void OnRollDice(BattleDiceBehavior b) => b.ApplyDiceStatBonus(new DiceStatBonus { dmgRate = Mathf.Min(100, (owner.bufListDetail.GetKewordBufStack(KeywordBuf.Quickness) / 2) * 15) });
    }

    public class DiceCardAbility_CindGray_SteadyEffort_1 : DiceCardAbilityBase
    {
        public static string Desc = "[On Hit] Inflict 2 Rupture. [On Crit] Inflict 2 Rupture";
        public override void OnSucceedAttack(BattleUnitModel t)
        {
            BufAdder.AddRupture(t, 2);
            var p = owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_Poise) as BattleUnitBuf_Poise;
            if (p != null && p.justCritted) BufAdder.AddRupture(t, 2);
        }
    }

    public class DiceCardAbility_CindGray_SteadyEffort_2 : DiceCardAbilityBase
    {
        public static string Desc = "[On Hit] Deal bonus damage equal to 1/4th of Haste";
        public override void OnSucceedAttack(BattleUnitModel target)
        {
            int haste = owner.bufListDetail.GetKewordBufStack(KeywordBuf.Quickness);
            int bonus = haste / 4;
            if (bonus > 0) target.TakeDamage(bonus, DamageType.Card_Ability, owner);
        }
    }

    public class DiceCardSelfAbility_CindGray_OneBraveStep : DiceCardSelfAbilityBase
    {
        public static string Desc = "[On Use] Restore 2 Light. If afflicted with Bind, restore 1 additional Light";
        public override void OnUseCard()
        {
            owner.cardSlotDetail.RecoverPlayPointByCard(2 + (owner.bufListDetail.GetKewordBufStack(KeywordBuf.Binding) > 0 ? 1 : 0));
        }
    }

    public class DiceCardAbility_CindGray_OneBraveStep_1 : DiceCardAbilityBase
    {
        public static string Desc = "[On Clash Win] Halve Bind on self (once per Scene). Add a 3~8 Counter Block Dice to queue";
        private static int scene = -1;

        public override void OnWinParrying()
        {
            if (scene != Singleton<StageController>.Instance.RoundTurn)
            {
                foreach (BattleUnitBuf b in owner.bufListDetail.GetActivatedBufList())
                {
                    if (b.bufType == KeywordBuf.Binding)
                    {
                        b.stack /= 2;
                        if (b.stack <= 0) b.Destroy();
                    }
                }
                scene = Singleton<StageController>.Instance.RoundTurn;
            }
            owner.cardSlotDetail.keepCard.AddBehaviours(ItemXmlDataList.instance.GetCardItem(behavior.card.card.GetID(), false), new List<BattleDiceBehavior> { new BattleDiceBehavior { behaviourInCard = new DiceBehaviour { Min = 3, Dice = 8, Type = BehaviourType.Standby, Detail = BehaviourDetail.Guard, MotionDetail = MotionDetail.G } } });
        }
    }

    public class DiceCardSelfAbility_CindGray_FruitsOfLabor : DiceCardSelfAbilityBase
    {
        public static string Desc = "Dice on this Page have a 50% chance of not reducing Rupture stacks when this unit has 5+ Haste. [On Use] Gain 3 Poise";
        public override void OnUseCard()
        {
            BufAdder.AddPoise(owner, 3);
        }
    }

    public class DiceCardAbility_CindGray_FruitsOfLabor_1 : DiceCardAbilityBase
    {
        public static string Desc = "[On Hit] Inflict 3 Rupture. If target has 15+ Rupture, apply 2 more Rupture";
        public override void OnSucceedAttack(BattleUnitModel t)
        {
            BufAdder.AddRupture(t, 3);
            var r = t.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_Rupture) as BattleUnitBuf_Rupture;
            if (r != null && r.stack >= 15) BufAdder.AddRupture(t, 2);
        }
    }

    public class DiceCardAbility_CindGray_FruitsOfLabor_3 : DiceCardAbilityBase
    {
        public static string Desc = "[On Hit] Deal bonus damage equal to 1/3rd of Haste";
        public override void OnSucceedAttack(BattleUnitModel target)
        {
            int haste = owner.bufListDetail.GetKewordBufStack(KeywordBuf.Quickness);
            int bonus = haste / 3;
            if (bonus > 0) target.TakeDamage(bonus, DamageType.Card_Ability, owner);
        }
    }

    public class DiceCardSelfAbility_CindGray_RacingTheFlow : DiceCardSelfAbilityBase
    {
        public static string Desc = "[Combat Start] Evade Die gain +3 Power this Scene";
        public override void OnStartBattle()
        {
            owner.bufListDetail.AddBuf(new BattleUnitBuf_CindGray_RacingTheFlow());
        }
    }

    public class BattleUnitBuf_CindGray_RacingTheFlow : BattleUnitBuf
    {
        public override void BeforeRollDice(BattleDiceBehavior b)
        {
            if (b.Detail == BehaviourDetail.Evasion) b.ApplyDiceStatBonus(new DiceStatBonus { power = 3 });
        }
        public override void OnRoundEnd() => Destroy();
    }

    public class DiceCardAbility_CindGray_RacingTheFlow_1 : DiceCardAbilityBase
    {
        public static string Desc = "[On Clash Win] 35% chance to gain 1 Haste next Scene";
        public override void OnWinParrying()
        {
            if (UnityEngine.Random.Range(1, 101) <= 35) owner.bufListDetail.AddKeywordBufByEtc(KeywordBuf.Quickness, 1, owner);
        }
    }

    public class DiceCardAbility_CindGray_RacingTheFlow_2 : DiceCardAbilityBase
    {
        public static string Desc = "[On Hit] Deal bonus damage equal to Light";
        public override void OnSucceedAttack(BattleUnitModel target)
        {
            int light = owner.cardSlotDetail.PlayPoint;
            if (light > 0) target.TakeDamage(light, DamageType.Card_Ability, owner);
        }
    }

    public class DiceCardSelfAbility_CindGray_Highlander : DiceCardSelfAbilityBase
    {
        public static string Desc = "[On Use] Restore Light equal to half of Haste on self (rounded down). If 3 or more Light was restored, draw Pages equal to half of Light restored (rounded up).";
        public override void OnUseCard()
        {
            int r = owner.bufListDetail.GetKewordBufStack(KeywordBuf.Quickness) / 2;
            owner.cardSlotDetail.RecoverPlayPointByCard(r);
            if (r >= 3) owner.allyCardDetail.DrawCards((r + 1) / 2);
        }
    }

    public class DiceCardAbility_CindGray_Highlander_2 : DiceCardAbilityBase
    {
        public static string Desc = "[On Clash Win] Double Stagger Damage dealt from deflect. Last Dice gains +2 Min and Max value.";
        public override void OnWinParrying()
        {
            behavior.ApplyDiceStatBonus(new DiceStatBonus { breakRate = 100 });
            card.ApplyDiceStatBonus(DiceMatch.LastDice, new DiceStatBonus { min = 2, max = 2 });
        }
    }

    public class DiceCardSelfAbility_CindGray_PhotonArc : DiceCardSelfAbilityBase
    {
        public static string Desc = "[Combat Start] Whenever this unit wins at least 2 Clashes on a Page they use, all their non-Counter Dice gain 1 Power for the Scene. [On Use] Restore Light equal to half of Haste on self, rounded down. If 3 or more Light was restored, draw Pages equal to half of Light restored (rounded up)";
        public override void OnStartBattle()
        {
            owner.bufListDetail.AddBuf(new BattleUnitBuf_CindGray_PhotonArcTracker());
        }

        public override void OnUseCard()
        {
            int r = owner.bufListDetail.GetKewordBufStack(KeywordBuf.Quickness) / 2;
            owner.cardSlotDetail.RecoverPlayPointByCard(r);
            if (r >= 3) owner.allyCardDetail.DrawCards((r + 1) / 2);
        }
    }

    public class BattleUnitBuf_CindGray_PhotonArcTracker : BattleUnitBuf
    {
        private int clashWins = 0;
        public override void OnWinParrying(BattleDiceBehavior behavior)
        {
            clashWins++;
            if (clashWins == 2)
            {
                _owner.bufListDetail.AddBuf(new BattleUnitBuf_CindGray_PhotonArcPower());
            }
        }
        public override void OnRoundEnd() => Destroy();
    }

    public class BattleUnitBuf_CindGray_PhotonArcPower : BattleUnitBuf
    {
        public override void BeforeRollDice(BattleDiceBehavior behavior)
        {
            if (behavior.Type != BehaviourType.Standby) behavior.ApplyDiceStatBonus(new DiceStatBonus { power = 1 });
        }
        public override void OnRoundEnd() => Destroy();
    }

    public class DiceCardAbility_CindGray_PhotonArc_1 : DiceCardAbilityBase
    {
        public static string Desc = "[On Crit] Target's Resistance is treated as Fatal";

        public override void OnRollDice()
        {
            var p = owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_Poise) as BattleUnitBuf_Poise;
            if (p != null && p.justCritted)
            {
                TreatResistanceAs(2.0f); // 2.0x is Fatal
            }
        }

        private void TreatResistanceAs(float targetMultiplier)
        {
            if (behavior.card?.target == null) return;

            AtkResist hpResist = behavior.card.target.Book.GetResistHP(behavior.Detail);
            float hpMult = GetResistValue(hpResist);
            int dmgRateOffset = 0;
            if (hpMult > 0f) dmgRateOffset = Mathf.RoundToInt(((targetMultiplier / hpMult) - 1f) * 100f);

            AtkResist bpResist = behavior.card.target.Book.GetResistBP(behavior.Detail);
            float bpMult = GetResistValue(bpResist);
            int breakRateOffset = 0;
            if (bpMult > 0f) breakRateOffset = Mathf.RoundToInt(((targetMultiplier / bpMult) - 1f) * 100f);

            behavior.ApplyDiceStatBonus(new DiceStatBonus { dmgRate = dmgRateOffset, breakRate = breakRateOffset });
        }

        private float GetResistValue(AtkResist resist)
        {
            switch (resist)
            {
                case AtkResist.Vulnerable: return 2.0f; 
                case AtkResist.Weak: return 1.5f;
                case AtkResist.Normal: return 1.0f;
                case AtkResist.Endure: return 0.5f;
                case AtkResist.Resist: return 0.25f;
                case AtkResist.Immune: return 0.0f;
                default: return 1.0f;
            }
        }
    }

    public class DiceCardAbility_CindGray_PhotonArc_2 : DiceCardAbilityBase
    {
        public static string Desc = "[On Crit] Target's Resistance is treated as Fatal";

        public override void OnRollDice()
        {
            var p = owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_Poise) as BattleUnitBuf_Poise;
            if (p != null && p.justCritted)
            {
                TreatResistanceAs(2.0f); 
            }
        }

        private void TreatResistanceAs(float targetMultiplier)
        {
            if (behavior.card?.target == null) return;

            AtkResist hpResist = behavior.card.target.Book.GetResistHP(behavior.Detail);
            float hpMult = GetResistValue(hpResist);
            int dmgRateOffset = 0;
            if (hpMult > 0f) dmgRateOffset = Mathf.RoundToInt(((targetMultiplier / hpMult) - 1f) * 100f);

            AtkResist bpResist = behavior.card.target.Book.GetResistBP(behavior.Detail);
            float bpMult = GetResistValue(bpResist);
            int breakRateOffset = 0;
            if (bpMult > 0f) breakRateOffset = Mathf.RoundToInt(((targetMultiplier / bpMult) - 1f) * 100f);

            behavior.ApplyDiceStatBonus(new DiceStatBonus { dmgRate = dmgRateOffset, breakRate = breakRateOffset });
        }

        private float GetResistValue(AtkResist resist)
        {
            switch (resist)
            {
                case AtkResist.Vulnerable: return 2.0f;
                case AtkResist.Weak: return 1.5f;
                case AtkResist.Normal: return 1.0f;
                case AtkResist.Endure: return 0.5f;
                case AtkResist.Resist: return 0.25f;
                case AtkResist.Immune: return 0.0f;
                default: return 1.0f;
            }
        }
    }

    public class DiceCardSelfAbility_CindGray_FlashForward : DiceCardSelfAbilityBase
    {
        public static string Desc = "[Combat Start] The first Dice of every Combat Page used by this unit this Scene gains Power equal to Haste on self (Up to 5)";
        public override void OnStartBattle()
        {
            int haste = owner.bufListDetail.GetKewordBufStack(KeywordBuf.Quickness);
            owner.bufListDetail.AddBuf(new BattleUnitBuf_CindGray_FF { p = Mathf.Min(5, haste) });
        }
    }

    public class DiceCardAbility_CindGray_FlashForward_1 : DiceCardAbilityBase
    {
        public static string Desc = "[On Clash Win] Gain 2 Haste next Scene (Up to 6 per Scene)";
        public override void OnWinParrying()
        {
            var limitBuf = owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_CindGray_FF) as BattleUnitBuf_CindGray_FF;
            if (limitBuf != null && limitBuf.hasteGainedThisTurn < 6)
            {
                owner.bufListDetail.AddKeywordBufByEtc(KeywordBuf.Quickness, 2, owner);
                limitBuf.hasteGainedThisTurn++;
            }
        }
    }

    public class BattleUnitBuf_CindGray_FF : BattleUnitBuf
    {
        public int p;
        public int hasteGainedThisTurn = 0;
        public override void BeforeRollDice(BattleDiceBehavior b) { if (b.Index == 0) b.ApplyDiceStatBonus(new DiceStatBonus { power = p }); }
        public override void OnRoundEnd() => Destroy();
    }

    public class DiceCardSelfAbility_CindGray_TriumphantPulse : DiceCardSelfAbilityBase
    {
        public static string Desc = "Dice on this Page deal 1% more damage for every 2% missing HP on self. When below 50% of your Max HP, this bonus automatically fixes to 50%.";
        public override void OnRollDice(BattleDiceBehavior b)
        {
            float m = 1f - ((float)owner.hp / owner.MaxHp);
            int d = (m >= 0.75f) ? 50 : (int)((m * 100f) / 2f);
            b.ApplyDiceStatBonus(new DiceStatBonus { dmgRate = d });
        }
    }

    public class DiceCardAbility_CindGray_TriumPulse_1 : DiceCardAbilityBase
    {
        public static string Desc = "[On Hit] Inflict 3 Rupture";
        public override void OnSucceedAttack(BattleUnitModel target) { BufAdder.AddRupture(target, 3); }
    }

    public class DiceCardAbility_CindGray_TriumPulse_2 : DiceCardAbilityBase
    {
        public static string Desc = "[On Hit] Inflict 3 Rupture";
        public override void OnSucceedAttack(BattleUnitModel target) { BufAdder.AddRupture(target, 3); }
    }

    public class DiceCardAbility_CindGray_TriumPulse_3 : DiceCardAbilityBase
    {
        public static string Desc = "[On Hit] Inflict 5 Rupture. [On Crit] Target's Resistance is treated as Weak";

        public override void OnRollDice()
        {
            var p = owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_Poise) as BattleUnitBuf_Poise;
            if (p != null && p.justCritted)
            {
                TreatResistanceAs(1.5f); // 1.5x is Weak
            }
        }

        public override void OnSucceedAttack(BattleUnitModel target) { BufAdder.AddRupture(target, 5); }

        private void TreatResistanceAs(float targetMultiplier)
        {
            if (behavior.card?.target == null) return;

            // HP Resistance Math
            AtkResist hpResist = behavior.card.target.Book.GetResistHP(behavior.Detail);
            float hpMult = GetResistValue(hpResist);
            int dmgRateOffset = 0;
            if (hpMult > 0f) dmgRateOffset = Mathf.RoundToInt(((targetMultiplier / hpMult) - 1f) * 100f);

            // Stagger (BP) Resistance Math
            AtkResist bpResist = behavior.card.target.Book.GetResistBP(behavior.Detail);
            float bpMult = GetResistValue(bpResist);
            int breakRateOffset = 0;
            if (bpMult > 0f) breakRateOffset = Mathf.RoundToInt(((targetMultiplier / bpMult) - 1f) * 100f);

            behavior.ApplyDiceStatBonus(new DiceStatBonus { dmgRate = dmgRateOffset, breakRate = breakRateOffset });
        }

        private float GetResistValue(AtkResist resist)
        {
            switch (resist)
            {
                case AtkResist.Vulnerable: return 2.0f;
                case AtkResist.Weak: return 1.5f;
                case AtkResist.Normal: return 1.0f;
                case AtkResist.Endure: return 0.5f;
                case AtkResist.Resist: return 0.25f;
                case AtkResist.Immune: return 0.0f;
                default: return 1.0f;
            }
        }
    }

    public class DiceCardAbility_CindGray_TriumPulse_4 : DiceCardAbilityBase
    {
        public static string Desc = "[On Hit] Inflict 5 Rupture. [On Crit] Target's Resistance is treated as Weak";

        public override void OnRollDice()
        {
            var p = owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_Poise) as BattleUnitBuf_Poise;
            if (p != null && p.justCritted)
            {
                TreatResistanceAs(1.5f); // 1.5x is Weak
            }
        }

        public override void OnSucceedAttack(BattleUnitModel target) { BufAdder.AddRupture(target, 5); }

        private void TreatResistanceAs(float targetMultiplier)
        {
            if (behavior.card?.target == null) return;

            AtkResist hpResist = behavior.card.target.Book.GetResistHP(behavior.Detail);
            float hpMult = GetResistValue(hpResist);
            int dmgRateOffset = 0;
            if (hpMult > 0f) dmgRateOffset = Mathf.RoundToInt(((targetMultiplier / hpMult) - 1f) * 100f);

            AtkResist bpResist = behavior.card.target.Book.GetResistBP(behavior.Detail);
            float bpMult = GetResistValue(bpResist);
            int breakRateOffset = 0;
            if (bpMult > 0f) breakRateOffset = Mathf.RoundToInt(((targetMultiplier / bpMult) - 1f) * 100f);

            behavior.ApplyDiceStatBonus(new DiceStatBonus { dmgRate = dmgRateOffset, breakRate = breakRateOffset });
        }

        private float GetResistValue(AtkResist resist)
        {
            switch (resist)
            {
                case AtkResist.Vulnerable: return 2.0f;
                case AtkResist.Weak: return 1.5f;
                case AtkResist.Normal: return 1.0f;
                case AtkResist.Endure: return 0.5f;
                case AtkResist.Resist: return 0.25f;
                case AtkResist.Immune: return 0.0f;
                default: return 1.0f;
            }
        }
    }

    public class DiceCardSelfAbility_CindGray_DawnlitAshenTrail : DiceCardSelfAbilityBase
    {
        public static string Desc = "This Page deals 1% more damage for every 1.5% missing HP on self. When below 50% of your Max HP, this bonus automatically fixes itself to 75%.";
        public override void OnRollDice(BattleDiceBehavior b)
        {
            float m = 1f - ((float)owner.hp / owner.MaxHp);
            int d = (m >= 0.50f) ? 75 : (int)((m * 100f) / 1.5f);
            b.ApplyDiceStatBonus(new DiceStatBonus { dmgRate = d });
        }
    }

    public class DiceCardAbility_CindGray_Dawnlit_1 : DiceCardAbilityBase
    {
        public static string Desc = "[On Hit] Inflict 10 Rupture. [On Crit] Target's Resistance is treated as Fatal";

        public override void OnRollDice()
        {
            var p = owner.bufListDetail.GetActivatedBufList().Find(x => x is BattleUnitBuf_Poise) as BattleUnitBuf_Poise;
            if (p != null && p.justCritted)
            {
                TreatResistanceAs(2.0f); // 2.0x is Fatal
            }
        }

        public override void OnSucceedAttack(BattleUnitModel target) { BufAdder.AddRupture(target, 10); }

        private void TreatResistanceAs(float targetMultiplier)
        {
            if (behavior.card?.target == null) return;

            AtkResist hpResist = behavior.card.target.Book.GetResistHP(behavior.Detail);
            float hpMult = GetResistValue(hpResist);
            int dmgRateOffset = 0;
            if (hpMult > 0f) dmgRateOffset = Mathf.RoundToInt(((targetMultiplier / hpMult) - 1f) * 100f);

            AtkResist bpResist = behavior.card.target.Book.GetResistBP(behavior.Detail);
            float bpMult = GetResistValue(bpResist);
            int breakRateOffset = 0;
            if (bpMult > 0f) breakRateOffset = Mathf.RoundToInt(((targetMultiplier / bpMult) - 1f) * 100f);

            behavior.ApplyDiceStatBonus(new DiceStatBonus { dmgRate = dmgRateOffset, breakRate = breakRateOffset });
        }

        private float GetResistValue(AtkResist resist)
        {
            switch (resist)
            {
                case AtkResist.Vulnerable: return 2.0f;
                case AtkResist.Weak: return 1.5f;
                case AtkResist.Normal: return 1.0f;
                case AtkResist.Endure: return 0.5f;
                case AtkResist.Resist: return 0.25f;
                case AtkResist.Immune: return 0.0f;
                default: return 1.0f;
            }
        }
    }

    public class DiceCardAbility_CindGray_Countermeasures : DiceCardAbilityBase
    {
        public override bool IsImmuneDestory => true;
        public static List<BattleDiceBehavior> usedDice = new List<BattleDiceBehavior>();

        public override void BeforeRollDice()
        {
            if (!usedDice.Contains(behavior))
            {
                owner.bufListDetail.AddKeywordBufByEtc(KeywordBuf.Binding, 2, owner);
                usedDice.Add(behavior);
            }

            int bonus = 0;
            var bufs = owner.bufListDetail.GetActivatedBufList();
            if (bufs.Exists(x => x is BattleUnitBuf_CindGray_StarvingMonster)) bonus = 3;
            else if (bufs.Exists(x => x is BattleUnitBuf_CindGray_HungryMonster)) bonus = 2;
            else if (bufs.Exists(x => x is BattleUnitBuf_CindGray_CravingMonster)) bonus = 1;

            if (bonus > 0) behavior.ApplyDiceStatBonus(new DiceStatBonus { min = bonus, max = bonus });
        }

        public override void OnLoseParrying()
        {
            owner.bufListDetail.AddKeywordBufByEtc(KeywordBuf.Binding, 1, owner);
            if (behavior.TargetDice != null && behavior.TargetDice.Detail == BehaviourDetail.Guard)
            {
                owner.breakDetail.RecoverBreak(behavior.TargetDice.DiceResultValue);
            }
        }
    }
}